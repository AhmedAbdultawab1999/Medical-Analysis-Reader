package com.example.mar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
